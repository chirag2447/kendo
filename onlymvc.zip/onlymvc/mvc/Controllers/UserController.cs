using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using mvc.Models;
using mvc.Repositories;

namespace Mvc.Controllers
{

    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;
        private readonly IUserRepository _userRepository;
        public UserController(ILogger<UserController> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult KendoLogin()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserModel user)
        {
            if (_userRepository.Login(user))
            {
                if (HttpContext.Session.GetString("userrole") == "admin")
                {
                    return RedirectToAction("Index", "Admin");
                }
                else if (HttpContext.Session.GetString("userrole") == "employee")
                {

                    return RedirectToAction("Index", "Employee");
                }
            }

            else
            {
                return Ok("wrong");
            }
            return Ok("wrong");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }


        public IActionResult Register()
        {
            ViewBag.msg = null;
            return View();
        }

        public IActionResult KendoRegister()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserModel user)
        {
            if (!_userRepository.IsUser(user.c_email))
            {

                _userRepository.AddUser(user);

            }
            else
            {
                ViewBag.msg = "User already exists";
                return View();

            }
            return RedirectToAction("Login");
        }


    }
}