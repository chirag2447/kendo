using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.repositories;
using Mvc.Models;

namespace Mvc.Controllers;

public class EmployeeController : Controller
{
    private readonly IEmployeeRepository employeeRepository;

    public EmployeeController(IEmployeeRepository logger)
    {
        employeeRepository = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult GetEmployees()
    {
        var emps = employeeRepository.GetEmployees();
        return Json(emps);
    }

    public IActionResult GetNameById(int id)
    {
        var name = employeeRepository.GetNameById(id);
        return Ok(name);
    }

    public IActionResult GetTeamName(int id)
    {
        var name = employeeRepository.GetTeamName(id);
        return Ok(name);
    }

    public IActionResult ManagersWithThreePlsDevs()
    {
        var names = employeeRepository.ManagersWithThreePlsDevs();
        return Json(names);
    }
    public IActionResult TeamWithTwoPlsDevs()
    {
        var names = employeeRepository.TeamWithTwoPlsDevs();
        return Json(names);
    }
    public IActionResult TesterWithTwoPlsTeam()
    {
        var names = employeeRepository.TesterWithTwoPlsTeam();
        return Json(names);
    }

    public IActionResult Report1()
    {
        return View();
    }
    public IActionResult Report2()
    {
        return View();
    }
    public IActionResult Report3()
    {
        return View();
    }



    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
