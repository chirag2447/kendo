// using system;
namespace mvc.Models;
public class EmployeeModel
{
    public int? c_id { get; set; }
    public string? c_name { get; set; }
    public int? c_designation_id { get; set; }
    public int? c_supervision_id { get; set; }
}