using mvc.Models;
using Npgsql;
// using system;
namespace mvc.repositories;
public class EmployeeRepository : IEmployeeRepository
{
    private readonly string conn;
    public EmployeeRepository(IConfiguration config)
    {
        conn = config.GetConnectionString("DefaultConnection");
    }

    public List<EmployeeModel> GetEmployees()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_name,c_designation_id,c_supervision_id from t_employee";
                var comm = new NpgsqlCommand(query, con);
                var r = comm.ExecuteReader();
                var employees = new List<EmployeeModel>();
                while (r.Read())
                {
                    var emp = new EmployeeModel
                    {
                        c_id = r.GetInt32(0),
                        c_name = r.GetString(1),
                        c_designation_id = r.GetInt32(2),
                        c_supervision_id = r.IsDBNull(r.GetOrdinal("c_supervision_id"))
                            ? null
                            : r.GetInt32(r.GetOrdinal("c_supervision_id"))
                    };
                    employees.Add(emp);
                }
                return employees;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public string GetNameById(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_name from t_employee where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                var r = comm.ExecuteReader();
                if (r.Read())
                {
                    return r.GetString(0);
                }
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return "";
    }

    public string GetTeamName(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select t.c_alliance from t_team t inner join t_employee_team_association a on a.c_team_id = t.c_id where a.c_employee_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                var re = comm.ExecuteReader();
                if (re.Read())
                {
                    return re.GetString(0);
                }

            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return "";
    }

    public List<EmployeeModel> ManagersWithThreePlsDevs()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = @"SELECT 

                        e.c_name

                        FROM
                            t_employee e
                        WHERE
                            e.c_id IN(
                                SELECT
                                    e.c_supervision_id
                                FROM
                                    t_employee e
                                WHERE
                                    e.c_id IN (
                                        SELECT
                                            e1.c_id AS supervisor_id
                                        FROM
                                            t_employee e1
                                        INNER JOIN
                                            t_employee e2
                                        ON
                                            e1.c_id = e2.c_supervision_id
                                        WHERE
                                            e2.c_designation_id = 3
                                        GROUP BY
                                            e1.c_id, e1.c_name
                                        HAVING
                                            COUNT(e1.c_id) > 3
                                    )
                            )";
                var comm = new NpgsqlCommand(query, con);
                var r = comm.ExecuteReader();
                var employees = new List<EmployeeModel>();
                while (r.Read())
                {
                    var emp = new EmployeeModel
                    {

                        c_name = r.GetString(0),

                    };
                    employees.Add(emp);
                }
                return employees;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public List<EmployeeModel> TeamWithTwoPlsDevs()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = @"SELECT 
                                t.c_alliance
                            FROM 
                                t_team t
                            WHERE 
                                t.c_id IN (
                                    SELECT 
                                        a.c_team_id
                                    FROM 
                                        t_employee_team_association a
                                    WHERE 
                                        a.c_employee_id IN (
                                            SELECT 
                                                e.c_id
                                            FROM 
                                                t_employee e
                                            WHERE 
                                                e.c_id IN (
                                                    SELECT 
                                                        e.c_supervision_id
                                                    FROM 
                                                        t_employee e
                                                    WHERE 
                                                        e.c_id IN (
                                                            SELECT 
                                                                e1.c_id AS supervisor_id
                                                            FROM 
                                                                t_employee e1 
                                                            INNER JOIN 
                                                                t_employee e2 
                                                            ON 
                                                                e1.c_id = e2.c_supervision_id
                                                            WHERE 
                                                                e2.c_designation_id = 3
                                                            GROUP BY 
                                                                e1.c_id, e1.c_name
                                                            HAVING 
                                                                COUNT(e1.c_id) > 2
                                                        )
                                                )
                                        )
                                )";
                var comm = new NpgsqlCommand(query, con);
                var r = comm.ExecuteReader();
                var employees = new List<EmployeeModel>();
                while (r.Read())
                {
                    var emp = new EmployeeModel
                    {

                        c_name = r.GetString(0),

                    };
                    employees.Add(emp);
                }
                return employees;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }


    public List<EmployeeModel> TesterWithTwoPlsTeam()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = @"SELECT 
                            e.c_name
                        FROM 
                            t_employee e
                        WHERE 
                            e.c_designation_id = 4 
                            AND e.c_supervision_id IN (
                                SELECT 
                                    e1.c_supervision_id
                                FROM 
                                    t_employee e1
                                GROUP BY 
                                    e1.c_supervision_id
                                HAVING 
                                    COUNT(e1.c_supervision_id) > 2
                            )";
                var comm = new NpgsqlCommand(query, con);
                var r = comm.ExecuteReader();
                var employees = new List<EmployeeModel>();
                while (r.Read())
                {
                    var emp = new EmployeeModel
                    {

                        c_name = r.GetString(0),

                    };
                    employees.Add(emp);
                }
                return employees;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }
}