using mvc.Models;

namespace mvc.repositories;
public interface IEmployeeRepository
{
    public List<EmployeeModel> GetEmployees();
    public string GetNameById(int id);
    public string GetTeamName(int id);
    public List<EmployeeModel> ManagersWithThreePlsDevs();
    public List<EmployeeModel> TeamWithTwoPlsDevs();
    public List<EmployeeModel> TesterWithTwoPlsTeam();



}