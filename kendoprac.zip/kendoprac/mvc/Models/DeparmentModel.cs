namespace mvc.Models;
public class DeparmentModel
{
    public int c_id { get; set; }
    public string c_name { get; set; }
}