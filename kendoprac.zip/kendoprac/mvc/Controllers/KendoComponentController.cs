using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;

namespace mvc.Controllers;

public class KendoComponentController : Controller
{
    private readonly ILogger<KendoComponentController> _logger;
    private readonly EmployeeRepository employeeRepository;

    public KendoComponentController(ILogger<KendoComponentController> logger, EmployeeRepository emp)
    {
        _logger = logger;
        employeeRepository = emp;
    }

    public IActionResult Index()
    {
        var emp = employeeRepository.GetEmployees();
        return View(emp);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(EmployeeModel emp)
    {
        employeeRepository.AddEmployee(emp);
        return RedirectToAction("index");
    }

    [HttpGet]
    public IActionResult GetDepartments()
    {
        var depts = employeeRepository.GetAllDepartments();
        return Json(depts);
    }

    [HttpPost]
    public IActionResult Upload(IFormFile Image)
    {
        var uniqueFilename = Guid.NewGuid() + "_" + Image.FileName;
        var uploadfolder = "wwwroot/images/" + uniqueFilename;
        var stream = new FileStream(uploadfolder, FileMode.Create);
        Image.CopyTo(stream);
        return Ok(new { fileName = uniqueFilename });
    }

    [HttpGet]
    public IActionResult Edit(int id)
    {
        var emp = employeeRepository.GetEmployeeById(id);
        return View(emp);
    }

    [HttpPost]
    public IActionResult Edit(EmployeeModel emp){
        employeeRepository.UpdateEmployee(emp);
        return RedirectToAction("index");
    }

    [HttpGet]
    public IActionResult Delete(int id)
    {
        employeeRepository.DeleteEmployee(id);
        return RedirectToAction("index");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
