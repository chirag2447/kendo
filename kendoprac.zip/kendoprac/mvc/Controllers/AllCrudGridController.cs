using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;

namespace mvc.Controllers;

public class AllCrudGridController : Controller
{
    private readonly ILogger<AllCrudGridController> _logger;
    private readonly EmployeeRepository employeeRepository;

    public AllCrudGridController(ILogger<AllCrudGridController> logger, EmployeeRepository ep)
    {
        _logger = logger;
        employeeRepository = ep;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult GetEmployees()
    {
        return Json(employeeRepository.GetEmployees());
    }
    [HttpPost]
    public IActionResult AddEmployee(EmployeeModel emp)
    {
        employeeRepository.AddEmployee(emp);
        return Ok();
    }

    public IActionResult GetDepartments()
    {
        return Json(employeeRepository.GetAllDepartments());
    }

    public IActionResult Upload(IFormFile Image)
    {
        var uniqueFilename = Guid.NewGuid() + "_" + Image.FileName;
        var filepath = "wwwroot/images/" + uniqueFilename;
        using (var stream = new FileStream(filepath, FileMode.Create))
        {
            Image.CopyTo(stream);
        }
        return Ok(new { fileName = uniqueFilename });
    }

    [HttpGet]
    public IActionResult DeleteEmployee(int id){
        employeeRepository.DeleteEmployee(id);
        return Ok();
    }

    [HttpPost]
    public IActionResult UpdateEmployee(EmployeeModel emp)
    {
        if (emp.c_image == null)
        {
            var image = employeeRepository.GetEmployeesFromId(emp.c_id.Value);
            emp.c_image = image.c_image;
        }
        employeeRepository.UpdateEmployee(emp);
        return Ok();
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
